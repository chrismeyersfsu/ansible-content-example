
def return_hello_world():
    return 'hello world'

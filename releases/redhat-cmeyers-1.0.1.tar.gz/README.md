Ansible Content Example
=======================

Various content pieces.

License
-------


[GNU General Public License v3.0](./LICENSE)
